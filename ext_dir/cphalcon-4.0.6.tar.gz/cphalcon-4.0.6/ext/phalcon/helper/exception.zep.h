
extern zend_class_entry *phalcon_helper_exception_ce;

ZEPHIR_INIT_CLASS(Phalcon_Helper_Exception);

