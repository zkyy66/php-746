
extern zend_class_entry *phalcon_domain_payload_status_ce;

ZEPHIR_INIT_CLASS(Phalcon_Domain_Payload_Status);

PHP_METHOD(Phalcon_Domain_Payload_Status, __construct);

ZEPHIR_INIT_FUNCS(phalcon_domain_payload_status_method_entry) {
	PHP_ME(Phalcon_Domain_Payload_Status, __construct, NULL, ZEND_ACC_FINAL|ZEND_ACC_PRIVATE|ZEND_ACC_CTOR)
	PHP_FE_END
};
