
extern zend_class_entry *phalcon_annotations_exception_ce;

ZEPHIR_INIT_CLASS(Phalcon_Annotations_Exception);

